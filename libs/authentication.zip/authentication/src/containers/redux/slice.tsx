import { createAsyncThunk, createSlice } from '@reduxjs/toolkit'
import axios, { AxiosResponse } from 'axios';
import { LoginPayload, RegisterPayload } from './payloads';
import { LoginResponse, RestaurantResponse, RestaurantReview, RestaurantState, ReviewResponse } from './reponses';


export const loginUser = createAsyncThunk(
  'auth/loginUser',
  async (payload: LoginPayload): Promise<LoginResponse> => {
    const response: AxiosResponse<LoginResponse> = await axios.get('http://127.0.0.1:5500/apps/mocks/login.json');
    return response.data;
  }
)

export const registerUser = createAsyncThunk(
  'auth/registerUser',
  async (payload: RegisterPayload): Promise<Number> => {
    const response: AxiosResponse<LoginResponse> = await axios.get('http://127.0.0.1:5500/apps/mocks/login.json');
    return response.status;
  }
)

export const getRestaurants = createAsyncThunk(
  'auth/getRestaurants',
  async (): Promise<RestaurantResponse[]> => {
    const response: AxiosResponse<RestaurantResponse[]> = await axios.get('http://127.0.0.1:5500/apps/mocks/restaurants.json');
    console.log("Get restaurants was called")
    return response.data;
  }
)

export const getReviews = createAsyncThunk(
  'auth/getReviews',
  async (id : string | undefined): Promise<ReviewResponse[]> => {
    const response: AxiosResponse<ReviewResponse[]> = await axios.get('http://127.0.0.1:5500/apps/mocks/reviews.json');
    console.log("Get reviews was called" + id)
    return response.data;
  }
)

export const getRestaurant = createAsyncThunk(
  'auth/getRestaurant',
  async (id : string | undefined): Promise<RestaurantResponse> => {
    console.log("Get restaurant was called with params: " + id);
    const response: AxiosResponse<RestaurantResponse> = await axios.get('http://127.0.0.1:5500/apps/mocks/restaurant.json');
    console.log(response.data);
    return response.data;
  }
)

const initialState: RestaurantState = 
  { restaurants:[], restaurant:{} as RestaurantResponse, isLoggedIn: true,
  user:{} as LoginResponse, reviews:[], review:{} as RestaurantReview }

// Then, handle actions in your reducers:
export const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    logout(state) {
      console.log('logging out');
      state.isLoggedIn = false;
      sessionStorage.removeItem("token");
    }
  },
    // standard reducer logic, with auto-generated action types per reducer
    extraReducers: (builder) => {
      // Add reducers for additional action types here, and handle loading state as needed
      builder.addCase(getRestaurants.fulfilled, (state, response) => {
        // Add restaurants to the slice array
        state.restaurants = response.payload;
        console.log(state.restaurants);
      })

      builder.addCase(loginUser.fulfilled, (state, response) => {
        // Set is Logged in to true
        state.isLoggedIn = true;
        state.user = response.payload;
      })

      builder.addCase(getRestaurant.fulfilled, (state, response) => {
        // Add restaurants to the slice array
        state.restaurant = response.payload;
        state.review = response.payload.review;
        console.log(state.restaurant);
      })

      builder.addCase(getReviews.fulfilled, (state, response) => {
        // Add restaurants to the slice array
        state.reviews = response.payload;
        console.log(state.reviews);
      })
    },
 
})