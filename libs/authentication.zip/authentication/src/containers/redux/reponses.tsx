import { Blob } from "buffer"

export interface LoginResponse {
    username: string,
    bearerToken: string,
    email: string
}

export interface ReviewResponse {
    id: number,
    name: string,
    message: string,
    rating: never
}

export interface RestaurantResponse{
    id: number,
    name: string,
    description: string,
    schedule: string,
    rating: number,
    category: string,
    status: string,
    review: RestaurantReview,
    latitude: number,
    longitude: number,
    image: Blob
}

export interface RestaurantReview {
    foodReview: number,
    staffReview: number,
    locationReview: number,
    priceReview: number,
    averageReview: number
}

export interface RestaurantState {
    restaurants: RestaurantResponse[],
    restaurant: RestaurantResponse,
    isLoggedIn: boolean,
    user: LoginResponse,
    reviews: ReviewResponse[],
    review: RestaurantReview
}